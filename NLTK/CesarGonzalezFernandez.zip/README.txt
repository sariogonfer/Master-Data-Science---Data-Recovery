usage: practica_nltk.py [-h] [-q Q_] [--corpus CORPUS]

Ejercicios con NLTK

optional arguments:
  -h, --help       show this help message and exit
  -q Q_            Numero de la pregunta. Por defecto todas.
  --corpus CORPUS  Directorio donde se encuentran el corpus. Por defecto
                   ./corpus/
